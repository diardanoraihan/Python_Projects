"""
Title: Homework Assignment #1: Variables
Details: Create a file describing my favorite song's attributes
"""

# The artist of the song
Artist = "Muse"
# The name of the song
Song = "Time is Running Out"
# The album of the song
Album = "Absolution"
# The genre of the song
Genre = "Alternative Rock"
# The year of the song released
Released = 2003
# The label of the album/song
Label = "East West"
# The song duration in seconds
DurationInSeconds = 241
# The song duration in minutes
DurationInMinutes = 4.01667

# Print every attributes above
print(Artist)
print(Song)
print(Album)
print(Genre)
print(Released)
print(Label)
print(DurationInSeconds)
print(DurationInMinutes)
